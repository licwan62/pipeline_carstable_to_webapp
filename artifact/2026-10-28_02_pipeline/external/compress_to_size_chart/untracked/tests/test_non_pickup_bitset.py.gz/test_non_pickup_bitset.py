from __future__ import annotations

from pathlib import Path
import sys
import unittest

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import process_tsv as pipeline


def sample_atoms() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "BRAND": "Porsche",
                "MODEL": "911",
                "START_YEAR": 2000,
                "YEAR_SINGLE": 2000,
                "Const": "Coupe",
                "VERSION_RAW": "",
                "BackSize": "A",
            },
            {
                "BRAND": "Porsche",
                "MODEL": "911",
                "START_YEAR": 2000,
                "YEAR_SINGLE": 2000,
                "Const": "Convertible",
                "VERSION_RAW": "",
                "BackSize": "A",
            },
            {
                "BRAND": "Porsche",
                "MODEL": "911",
                "START_YEAR": 2000,
                "YEAR_SINGLE": 2001,
                "Const": "Coupe",
                "VERSION_RAW": "",
                "BackSize": "A",
            },
            {
                "BRAND": "Porsche",
                "MODEL": "911",
                "START_YEAR": 2000,
                "YEAR_SINGLE": 2001,
                "Const": "Convertible",
                "VERSION_RAW": "",
                "BackSize": "B",
            },
            {
                "BRAND": "Porsche",
                "MODEL": "911",
                "START_YEAR": 2000,
                "YEAR_SINGLE": 2002,
                "Const": "Coupe",
                "VERSION_RAW": "Turbo",
                "BackSize": "A",
            },
        ]
    )


class NonPickupBitsetTests(unittest.TestCase):
    def assert_matches_legacy(self, lossless: pd.DataFrame, atoms: pd.DataFrame) -> None:
        legacy, legacy_stats, _ = pipeline._build_non_pickup_high_legacy(lossless, atoms)
        optimized, optimized_stats, _ = pipeline.build_non_pickup_high_new(lossless, atoms)

        sort_columns = [
            "BRAND",
            "MODEL",
            "START_YEAR",
            "year_start",
            "year_end",
            "BACKSIZE",
            "CONST",
            "VERSION",
        ]
        legacy = legacy.sort_values(sort_columns, kind="mergesort").reset_index(drop=True)
        optimized = optimized.sort_values(sort_columns, kind="mergesort").reset_index(drop=True)
        pd.testing.assert_frame_equal(legacy, optimized, check_dtype=False)
        self.assertEqual(legacy_stats, optimized_stats)

    def test_safe_and_conflicting_merges_match_legacy(self) -> None:
        atoms = sample_atoms()
        lossless = pipeline.build_non_pickup_lossless_new(atoms)
        self.assert_matches_legacy(lossless, atoms)

    def test_invalid_initial_partition_falls_back_to_legacy(self) -> None:
        atoms = sample_atoms().iloc[:2].copy()
        lossless = pipeline.build_non_pickup_lossless_new(atoms)
        lossless = pd.concat([lossless, lossless.iloc[[0]]], ignore_index=True)
        self.assert_matches_legacy(lossless, atoms)


if __name__ == "__main__":
    unittest.main()
